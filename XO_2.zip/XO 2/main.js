const cells = document.querySelectorAll(".element")
var currentClick = "x"
x = 0,
o = 0


xscore = document.querySelector('#score-x')
oscore = document.querySelector('#score-o')


const winCases = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9],
    [1, 4, 7],
    [2, 5, 8],
    [3, 6, 9],
    [1, 5, 9],
    [3, 5, 7]

]

cells.forEach(element => {
    element.addEventListener('click', function (event) {

        if (!event.target.innerText) {
            event.target.innerText = currentClick;
            checkWin()
             currentClick === "x" ? currentClick = "o" : currentClick = "x";
            
        }
    })

});

function checkWin() {
    let win = false
    let index = 0
    while (!win && index < winCases.length) {
        let cell1 = document.getElementById(winCases[index][0]).innerText
        let cell2 = document.getElementById(winCases[index][1]).innerText
        let cell3 = document.getElementById(winCases[index][2]).innerText

        if (cell1 && cell2 && cell3 && cell1 == cell2 && cell2 == cell3 && cell1 == 'x') {
            win = true
            x++;
            break;
        } else if (cell1 && cell2 && cell3 && cell1 == cell2 && cell2 == cell3 && cell1 == 'o') {
            win = true;
            o++;
            break;
        }
        index++;

    }


     if (win) {
        
         xscore.innerText = x
         oscore.innerText = o
    
         restartGame()
     } 

    function restartGame() {
        currentClick = 'x'
        cells.forEach(element => element.textContent = "")
        
    }

}